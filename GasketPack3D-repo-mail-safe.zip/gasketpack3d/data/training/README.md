# The works' own sheets

The files the software was built from. Nothing here is read at run time — the
figures are transcribed into `parts/`. They are kept so that any constant in the
app can be traced back to the sheet it came from, and so the next person can check
the transcription rather than trust it.

```
prn/      signed packing check lists and annexures (scans)
charts/   weight charts and the material density sheet
stock/    RTJ BOX.xlsx — ring cartons and corrugated stock
misc/     sheets received but not yet used
```

What each one taught, and what changed because of it, is in
[../../docs/TRAINING-DATA.md](../../docs/TRAINING-DATA.md).

These are confidential business records, including customer names, purchase order
numbers and prices-adjacent data. They stay inside the company.
