# Read this first — three files were renamed to get past the mail filter

Mail systems block archives that contain scripts (`.sh`, `.js`, `.mjs`), so in this
copy three files carry an extra `.txt` on the end. Nothing else was changed.

| In this zip | Rename it back to |
|---|---|
| `build.sh.txt` | `build.sh` |
| `tools/run_tests.sh.txt` | `tools/run_tests.sh` |
| `tools/split_html.mjs.txt` | `tools/split_html.mjs` |

Rename them by hand — there are only three — or run one of these from the folder:

**macOS / Linux**

```sh
mv build.sh.txt build.sh
mv tools/run_tests.sh.txt tools/run_tests.sh
mv tools/split_html.mjs.txt tools/split_html.mjs
chmod +x build.sh tools/run_tests.sh
```

**Windows PowerShell**

```powershell
Rename-Item build.sh.txt build.sh
Rename-Item tools\run_tests.sh.txt run_tests.sh
Rename-Item tools\split_html.mjs.txt split_html.mjs
```

This copy also has no `.git` folder, so it is a plain set of files rather than a
repository. To make it one:

```sh
git init
git add -A
git commit -m "GasketPack 3D — repository, documentation and build"
```

Everything else — the documentation, the handbook PDF, the folder layout — is
exactly as it was.
