# GOODRICH GASKET — packing rules as the software applies them

This is the works' own packing practice, written down. Every rule here came from
GOODRICH GASKET PRIVATE LIMITED (Flosil) — from the packing sheets, the signed
packing check lists and the annexures — and every one of them is implemented in
GasketPack 3D. Where the app guessed, it says so; where a figure was read off a
real job, the job is named.

Numbers in **bold** are the ones the shop floor works to.

---

## 1 · The four packing types

| Type in the app | Name | When it is used |
|---|---|---|
| Type 2 | **KNPC** | the KNPC line-item sheets — a corrugated square between *every* ring, one item code per box |
| Type 3 | **Consolidated / general** | everything in one PRN goes in one box, sized to the largest piece |
| Type 4 | **Boxes as given** | the packing check list already numbers the boxes — the app obeys it |
| Type 5 | **Export packing** | the export packing sheet |
| Type 6 | **Domestic packing** | the domestic packing sheet |

Types 5 and 6 are different rules, not variations of one rule. The same list of
gaskets packs differently depending on which one is chosen, and the app can show
the two side by side before you commit (**Suggested box layout**).

---

## 2 · Bundle counts by size

A ring is strapped into a bundle of a fixed count **before anything else happens**.
It is the bundle, not the single ring, that is nested or laid in the box.

### Export — spiral wound

| Size band | Pieces per bundle |
|---|---|
| 0.5″ – 1″ | **25** |
| 1.5″ – 8″ | **10** |
| 10″ – 24″ | **5** |
| above 24″ | **5** |

### Domestic — spiral wound

| Size band | Pieces per bundle |
|---|---|
| 0.5″ – 4″ | **24** |
| 6″ – 8″ | **10** |
| 10″ | **5** |
| 12″ – 24″ | **1 — on a corrugated square, singly** |
| above 24″ | **1 — on a corrugated square, singly** |

### Soft cut (SC) — the same counts either way

| Size band | Pieces per bundle |
|---|---|
| 0.5″ – 4″ | **24** |
| 6″ – 8″ | **10** |
| 10″ and above | **5** |

Soft cut is packed informally — the counts are kept, but it may be laid in the box
in any arrangement that will not damage it.

> Anything outside these bands is a question for the works, not a guess. The app
> flags a line it cannot band and says so in the warnings.

All of these counts are editable in the app under **Bundle counts by size…**, with
a reset back to the works figures.

---

## 3 · Nesting — a bundle goes into the tightest bore that will take it

The nester does not look for the first bore that fits; it looks for the **tightest**
one. That single rule is what reproduces the works' own handwritten sets from a
Class 150 range:

```
24″ ⊃ 18″ ⊃ 12″ ⊃ 8″ ⊃ 5″
20″ ⊃ 14″ ⊃ 10″
22″ ⊃ 16″
```

Two things follow from the real diameters, and both are in the charts:

- **20″ is not in the first set.** Its 606.6 mm outer ring will not pass the 24″
  inner-ring bore of 603.3 mm.
- **The 10″ is saved for the 14″ bore**, which has only **9.4 mm** of slack. That is
  why the nest gap defaults to **5 mm** — at 10 mm the works' own sheet cannot be
  reproduced.

Nesting never crosses **type or pressure class** (Class 150 does not nest inside
Class 300), unless the operator deliberately relaxes the match to "same type, any
rating".

### Domestic nesting is capped

Nothing is nested **above 10″** on the domestic rule. The two chains the domestic
sheet shows fall straight out of the same nester:

```
10″ ⊃ 6″ ⊃ 3″
8″  ⊃ 5″ ⊃ 2½″
```

4″ is nested in the rings. **0.5″ – 2″ act as filler** — they drop into any free bore
of the same rating, or into the gaps around the sets, to use the box up.

---

## 4 · What rides on cardboard, and what gets its own box

| Gasket | Export | Domestic |
|---|---|---|
| Spiral wound | bundled, then nested | bundled to 10″; **12″–24″ singly on a corrugated square** |
| Soft cut (SC) | bundled, packed informally | same bundles, same freedom |
| Kammprofile (KAM) | **one piece per 3-ply corrugated square** | same |
| Double jacketed (DJ) | **one piece per 3-ply corrugated square** | same |
| RTJ ring joint | **its own carton**, cartons then boxed | same |
| Insulation kit (ISK) | **its own box** | same |

**No box holds two gasket types** — they are fragile and they damage each other.
That is the written rule, and the app enforces it.

### The one exception, now the default

Their own boxes mix the **small sizes**. PRN 251000300 Box 1 holds soft cut, RTJ and
a 10″ spiral wound together; PRN 251000328 Box 1 holds twelve RTJ ring cartons and a
pair of 2″ spiral wound. So the app allows pieces **at or under 24″** to share one
box, and the switch is on by default:

> *"…except the small sizes — one shared box, which is what their own boxes do."*

A **carded** ring (the 12″-and-up domestic rule) is never pulled into a shared box —
that is a rule of its own, and PRN 251000304 keeps the carded box separate from the
bundled one.

---

## 5 · The corrugated stock

The app carries the box shop's **own stock list**, not arbitrary cardboard:

- **19 square sheet sizes**, 457.2 mm up to 1900 mm, each with its ply.
- **120 RTJ carton sizes**, by ring number (R-OCT, R-OVAL, RX, BX), each with its
  side, depth and ply. A ring with no carton of its own takes the next size up, and
  the app says the size was rounded.
- 150 gsm board; the weight of every square and every carton is carried into the
  box weight.

How many rings to a square:

| Rule | Rings per corrugated square |
|---|---|
| KNPC | **1** — a sheet between every ring |
| Domestic / export | **10** |

PRN 251000304's Box 1 is the proof that it is not one sheet per ring outside KNPC —
47 carded rings would not fit the 11″ depth they used.

---

## 6 · Box sizing

- **One inch of clear headroom** is kept above the stack in every box, on every
  rule, so the lid never presses on the gaskets and the top dunnage has somewhere
  to go.
- Clearance round the contents: **50 mm a side** for a bare bundle, **25 mm a side**
  for a carded ring or a ring carton (the card already carries its own margin).
- **Bow allowance** — a spiral wound ring does not lie flat. The layer pitch is at
  least **OD × 1.25 %** (about OD ÷ 80). This is applied to **spiral wound only**;
  soft cut lies flat and gets none. It was read off PRN 251000300.
- **300 kg** is the working weight cap for a box (the app's general cap is editable).
- **30 inches** is the deepest box the app will build before it starts a second one.
- Sizes are rounded **up to whole inches**, and the stock box ladder is built from
  their own annexures: 12, 16, 21×21×25, 26×26×11, 30, 34×34×8, 35×35×16,
  39×39×28, 43×43×16, 47×47×25, 51, 55×55×14, 63, 71×71×10.
- **Size clustering** — a 60″ ring does not share a box with a 30″ one. Sizes within
  about 90 % of each other go together; near-empty clusters are merged.

### On an RTJ job the carton sizes the box

PRN 251000328: the biggest ring is an R49, its stock carton is **283 mm** square, and
their box is **14 in** — 283 mm plus **36 mm a side**, one carton wide and nothing
spare. Twelve cartons stacked make the **10 in** depth. So on a ring-joint job the box
follows the carton list, not the ring diameter plus a clearance.

---

## 7 · Weight

- Every weight comes from the **works' own charts** where a chart covers the line:
  spiral wound (299 size × class rows, including the 26″-and-up Series A and B),
  Kammprofile (151), soft cut plain and with a steel insert (281 each), RTJ rings
  (232 ring numbers), insulation kits (391 rows, per complete set), against the
  **82-material density sheet**.
- Chart weights were re-derived from geometry and density and matched the works
  figures exactly, so a weight can also be recomputed for a different material.
- The empty box is modelled from its surface and board thickness. A real works box
  runs about **9 – 10 kg per m² of box surface** (12 mm ply) — PRN 251000304's Box 2
  works out at 9.5 and confirms the model within 4 %.
- When an annexure gives a gross weight, **the annexure figure is used** — but if it
  disagrees with the contents plus a box of that size by more than 15 %, the app
  flags it and expresses the gap as kg per m² of box, so the packer can judge it:
  far above 10 means a pallet or skid base, or a mis-keyed weight; far below means
  the gross may have been copied from a smaller box.

---

## 8 · Loading

- Vehicles are the Indian road fleet (Tata Ace / Intra through 22 ft, 32 ft and the
  container sizes), with their inner dimensions and payloads.
- Boxes are placed by a block/wall packer with tier support checks, centre-of-gravity
  reporting and a load-centre warning.
- Lashing (over-top, X-lash, box straps), corner boards and tarpaulin are planned and
  the webbing is totalled.

---

## 9 · What the app prints

| Sheet | Format | What it is |
|---|---|---|
| PACKING CHECK LIST | PDF + Excel | the works format, one row per line item with Box No and the Production / Packing / Quality columns |
| ANNEXURE | PDF + Excel | the instruction checklist, recommended truck size, and the Maximum Box Size Outer table in inches with quantity and gross weight |
| Packing list | Excel | Summary, Gasket Items, Box Manifest, **Box Contents** (one row per line per box), Loading Sequence, Vehicles, Securing & Cover |
| Loading plan | PDF | overview, per-vehicle 3-D and 2-D plans, box build-up, **What is in each box**, item summary, securing |
| Project | JSON | the whole job, reloadable |
