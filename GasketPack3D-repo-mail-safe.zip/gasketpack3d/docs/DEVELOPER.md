# Developer notes

## The shape of it

GasketPack 3D ships as **one self-contained HTML file** — no CDN, no npm at run
time, no build step on the user's machine. The source is kept as parts and
concatenated:

```sh
./build.sh            # parts/* -> dist/GasketPack3D.html
```

`build.sh` is a `cat` in a fixed order. The order matters:

| # | Part | What is in it |
|---|---|---|
| 1 | `01_head.html` | the whole stylesheet — design tokens, light default, `[data-theme="dark"]` |
| 2 | `02_body.html` | the markup: header, sidebar, tabs, panels, right rail |
| 3 | `03b_chart.js` | the works weight charts (must precede `03_data.js`) |
| 4 | `03c_chartfn.js` | chart lookup |
| 5 | `03_data.js` | `APP`, `U`, materials, families, vehicles, crates, `S` (the state) |
| 6 | `03d_cartons.js` | RTJ carton list, corrugated stock (must follow `03_data.js`) |
| 7 | `04_crate.js` | crate inner volume, tare |
| 8 | `04b_knpc.js` | the KNPC / free-text line parser (`parseGasketText`, `knpcMaterial`) |
| 9 | `04c_plan.js` | the generic planners (Types 0–2) |
| 10 | `04d_consol.js` | Type 3, the stock box ladder, `pickBoxIn` |
| 11 | `04e_pcl.js` | packing-check-list import, Type 4 (`planCratesGiven`) |
| 12 | `04f_export.js` | Types 5 and 6 — bands, nester, clusters, shelves, the adviser |
| 13 | `05_pack.js` | vehicle packing, validation, statistics |
| 14 | `06_r3d.js` | the canvas-2D 3-D engine (`makeR3D`) |
| 15 | `07_r2d.js` | the 2-D plan renderer |
| 16 | `08_export.js` | XLSX writer / reader, PDF writer |
| 17 | `09_ui.js` | all the UI, the box layup, the renderers' scene building |
| 18 | `10_out.js` | reports, the works jobs, save / load, help, boot, theme |
| 19 | `10b_forms.js` | the PACKING CHECK LIST and ANNEXURE forms |

Nothing is minified. The file is around 750 KB and opens instantly.

### Reconstructing the parts from a built file

`tools/split_html.mjs` splits a built `GasketPack3D.html` back into `parts/`, using
the banner comment at the head of each part. Use it if only the built file survives:

```sh
node tools/split_html.mjs dist/GasketPack3D.html parts/
./build.sh && diff <(cat dist/GasketPack3D.html) <(cat dist/GasketPack3D.html)
```

---

## The 3-D engine

`makeR3D(canvas)` is a painter's-algorithm renderer on a 2-D canvas — no WebGL, so
it works on any machine in the works.

- `meshCyl` / `meshBox` build faces; faces are sorted per frame by `layer` then depth.
- `R.paper` is the theme flag: `true` on the light theme. It lifts the ambient light,
  softens the face outlines, lightens the label chips and darkens the grid. A face
  lit at 0.34 reads as shadow on a dark ground and as near-black on white.
- `R.fit()`, `R.bounds` (shell + objects, not extras), angular-sector cutaway.
- **Level of detail**: `detail` (≤ 2 boxes), `ring` (≤ 12), `simple` (above), plus
  `segFor(od)` for the facet count, a mesh budget per frame and a layup cache. The
  overview is capped at 24 boxes.
- Performance is a tested budget, not a hope — see `harness/perf_test.mjs`. The
  overview went from 370 ms/frame to 9 ms/frame when the LOD tiers went in, and the
  test fails if it regresses.

## The box layup

`crateLayup(list, inner, cfg)` is what turns a box's contents into a picture:

1. every pack unit the box holds — a bundle, a ring on its square, a ring carton
2. like with like into piles
3. piles placed by bottom-left packing **on platforms**: the floor is the first
   platform and the top of every pile becomes another, which is what stops a wide
   shallow pile wasting the box above it
4. a pile that will not fit is split and the halves are tried in the gaps
5. a bundle whose diameter clears a free bore goes in the bore

It records what each pile stands on, which is what the stack list reads out.

---

## Tests

Node suites (no browser) — `node <file>`:

| File | Asserts |
|---|---|
| `tests/test.mjs` | core geometry, weights, crates |
| `tests/nest_test.mjs` | the nester, including the works' three sets |
| `tests/knpc_test.mjs` | the line parser, families and materials |
| `tests/rules2_test.mjs` | the rule matrix |
| `tests/quick_test.mjs` | the broad sweep |
| `tests/export_test.mjs` | Types 5 and 6 end to end |
| `tests/prn300_test.mjs` | PRN 251000300 rebuilt |
| `tests/prn304_test.mjs` | PRN 251000304 rebuilt, and the box-weight reading |
| `tests/prn316_test.mjs` | PRN 251000316 rebuilt |
| `tests/prn328_test.mjs` | PRN 251000328 rebuilt, RTJ cartons, SI / F5 |

Browser harnesses (Playwright, headless Chromium) — `node <file>`:

`browser · edge · narrow · rules_browser · chart_browser · edit_browser ·
save_browser · knpc_browser · form_browser · pcl_browser · boot_prn · exp_browser ·
layup_browser · allbox_browser · rail_browser · jobs_browser · pile_browser ·
boxwise_browser · theme_browser · perf_test`

Each exits non-zero on failure and prints what it checked. `theme_browser` checks
that the app opens light, that both renderers switch ground with the theme, that the
choice survives a reload, and that no text ends up the same colour as what is behind
it. `perf_test` holds the frame budget.

```sh
./tools/run_tests.sh          # node suites, then the harnesses
```

Playwright expects the browser at `/opt/pw-browsers`; do not let it download its own.

---

## Adding a works job

1. Type the check list into `parts/10_out.js` as `PRN<nnn>_ROWS`, in the importer's
   row format (the same shape the Excel importer produces), with the ANNEXURE rows
   under it.
2. Add an entry to `WORKS_JOBS` with `seq` (higher = newer), `sent`, `prn`, `po`,
   `poDate`, `cust`, `veh`, `rows` and a `note` saying what the job teaches.
3. Write `tests/prn<nnn>_test.mjs`: the lines as typed, the pieces, the boxes Type 4
   rebuilds, and whatever the job proves.
4. Bump `APP.ver` in `parts/03_data.js`, update `harness/jobs_browser.mjs`'s expected
   count, and run everything.

## Conventions

- Comments explain **why**, in the works' own terms, and name the job a constant came
  from. A constant without a provenance comment is a bug waiting to be argued about.
- Every colour in the CSS is a token. Nothing hardcodes a shade, because the light
  and dark palettes are two sets of the same tokens.
- Canvas colours come from `R.paper`, never from the stylesheet.
- No browser storage except the remembered theme.
