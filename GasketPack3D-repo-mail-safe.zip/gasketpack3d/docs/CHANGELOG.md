# Changelog

Versions are stamped into the app (`APP.ver`, shown in the header) so an old copy of
the file is obvious at a glance.

## 4.1.0

- **The light theme on real boxes.** Putting PRN 251000304's Box 1 on a white ground
  for the first time showed a black mass: a face lit at 0.34 reads as shadow on dark
  and as near-black on white. Lifted the ambient, softened the per-face outline and
  the stack banding, faded the boards you look *through*, and lightened the kraft.
- **Box-weight warning now says what the gap means** — the difference between the
  annexure gross and the contents is expressed as kg per m² of box surface, with the
  reading named: far above 10 is a pallet or skid base or a mis-key, far below means
  the gross may have been copied from a smaller box. Calibrated on PRN 251000304,
  whose Box 2 works out at 9.5 kg/m² (12 mm ply) and whose Box 1 implies 29.5.

## 4.0.0 — light by default

- The whole stylesheet rebuilt on design tokens, light by default, with the old
  night palette behind `[data-theme="dark"]` and a **☾** toggle that remembers.
- The 3-D renderer's dormant `paper` mode switched on with the theme: darker grid
  and edges, light label chips, dark-side highlight.
- **Suggested box layout** stopped printing forty-seven identical chains down one
  cell — repeats are counted (`12" × 27`), longest first, capped at six.
- Crate breakdown's `kg/box`, which was 0 on Types 3–6, became *kg, all pcs*.

## 3.17.0 — what is in each box

- **Box-wise contents** under the box picture: one row per box, numbered as the
  annexure numbers them, with every line it holds — code, quantity, how packed,
  line weight, nested or not — and net / tare / gross / CBM. Click a row to open
  that box; **Group same builds** for very large orders.
- The same list in two printed places: a **Box Contents** sheet in the packing list
  workbook (one row per line per box) and a **What is in each box** section in the
  loading plan PDF.
- Parser faults the new sheet exposed: soft cut was labelled "Corrugated metal",
  `NON ASBESTOS BS7531` and `BUTYL` were read as a spiral-wound assembly, and
  `RTJ R16 SS316L` lost its grade. All fixed; grades keep their L / H / Ti suffix.

## 3.15.0 — the stack list

- Every box's picture lists its stacks — item code, pieces, how packed, diameter,
  and where the pile stands (on the floor, on top of another pile, in a bore).
  Click one and the rest of the box goes to glass. Prompted by two 2″ gaskets that
  were genuinely in the box and genuinely invisible, sitting on a stack of ring
  cartons at 95 mm.

## 3.14.0 — PRN 251000328 (TEMA India)

- The job added, with its lesson: **the RTJ carton sizes the box** (R49's 283 mm
  carton plus 36 mm a side is their 14 in box; twelve cartons stacked make the
  10 in depth).
- `SI`, `F5`, `F9`, `F11`, `F12`, `F22`, `F51`, `F53` recognised as materials; an
  RTJ keeps whatever bar is named.
- **Small sizes may share a box** — now the default, on the evidence of their own
  Box 1s on PRN 300 and PRN 328. A carded 12″-and-up ring is never pulled in.
- The works' standard 370 mm domestic box now wins a tie only when the tight box
  would be a tower (deeper than it is wide).

## 3.13.0 and earlier — the rules going in

- **PRN 251000316** (BHEL): a box sized by quantity rather than ring; a description
  quoting both the gasket and the ring thickness.
- **PRN 251000304** (Sharp Tanks): the 12″ split proved; one sheet per ring
  disproved outside KNPC; multi-box cells like `2,3,4 (50/50/10)`.
- **PRN 251000300** (L&T): the domestic calibration — 2 in clearance, bow ≈ OD ÷ 80
  on spiral wound only, tare × 1.6, a 300 kg cap, size clustering, the depth ladder.
- **PRN 251000267** (Toyo): the consolidated habit, and the first stock box size.
- **Type 5 export** and **Type 6 domestic** written from the works' sheets: bundle
  bands, the tightest-bore nester that reproduces 24⊃18⊃12⊃8⊃5, 20⊃14⊃10 and 22⊃16,
  cards for KAM/DJ, cartons for RTJ, boxes for ISK, no mixing of types.
- **RTJ BOX.xlsx** brought in as the carton and corrugated stock list.
- **The clear inch** of headroom above every stack, on every rule.
- The **box layup** rewritten from one tower per line to piles on platforms, so a
  box is filled the way a packer fills it — and 658 pieces stopped being dropped.
- **Performance**: 370 ms/frame to 9 ms/frame with LOD tiers, facet counts by
  diameter, a mesh budget and a layup cache; held by a test.
