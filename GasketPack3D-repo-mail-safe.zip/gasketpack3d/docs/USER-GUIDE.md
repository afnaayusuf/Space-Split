# GasketPack 3D — how to use it

One file, `dist/GasketPack3D.html`. Double-click it. It runs in any modern browser,
needs no installation, no network and no login, and it keeps nothing on a server.
Copy it onto a laptop in the packing hall and it works the same there.

---

## 1 · Getting a job into it

Four ways, in order of how often they are used:

**A works job already on file.** The sidebar's **Works jobs** panel holds every
signed packing check list that has been built in, newest first. Click one and the
item lines, the box numbers and the annexure sizes come in exactly as the sheet has
them. The app opens on the newest.

**Import a packing check list.** `⭳ Import` reads the works' own check-list
spreadsheet — SL, PO SL, TYPE, Cust Item Code, Description Of Goods, Total Qty,
Actual Qty, UOM, Box No — and the ANNEXURE table under it. A Box No cell like
`2,3,4 (50/50/10)` is understood as a split across three boxes. Sizes, diameters and
weights for each line still come off the works charts, so a line that only says
`SPW 20"X900#` still yields a real diameter, bore and weight.

**Quick entry.** Type a line: `SPW 6" 150# 316L/Graphite x 200`. Name, size in inches
or DN, pressure class, OD×ID×thk, material and quantity, in any order.

**Open a saved project.** `Open` reloads a project JSON, including the rule settings.

Fill **PRN / PO details** and the printed forms fill their own headers.

---

## 2 · Choosing the rule

The **making rule** selector decides how the pieces are packed:

- **Type 0 · Default box** — plain box, best fit
- **Type 1 · Nesting** — smaller sizes inside larger bores
- **Type 2 · KNPC** — a corrugated sheet between every ring, one code per box
- **Type 3 · Consolidated** — everything in the PRN in one box
- **Type 4 · Boxes as given** — obey the box numbers on the check list
- **Type 5 · Export packing**
- **Type 6 · Domestic packing**

Before committing, press **Suggested box layout…**. It reads the whole list against
both the export and the domestic rules and shows what each would cost in boxes,
pieces, weight and CBM, then packs it that way on one click.

**Bundle counts by size…** opens the four band sheets (export SPW, export SC,
domestic SPW, domestic SC). They are editable, with a reset back to the works
figures.

Press **⚡ Optimise Load**.

---

## 3 · The four tabs

### 1 · Boxes — what is inside each box

- The **box rail** down the left lists every box in the shipment. Click one to look
  inside it; **▦ All** lays the whole shipment out side by side.
- The picture shows the pieces as they really sit: bundles, rings on corrugated
  squares, ring cartons, pieces nested in bores, the boards of the box and the clear
  inch above the stack. **Box walls** and **Cutaway** control what you see through.
- The **stack list** under the box figures names every pile in that box — item code,
  pieces, how they are packed, diameter, and where the pile stands (on the floor, on
  top of another pile, in the bore of a ring). **Click a line and the rest of the box
  goes to glass** so that pile alone shows solid. Two 2″ gaskets on top of a stack of
  ring cartons are invisible otherwise.
- **What is in each box**, under the picture, is the box-wise list: Box 1, Box 2,
  Box 3 … each with its outer size, making rule and every line it holds, with the
  quantity, how it is packed, the line weight, and net / tare / gross / CBM. Click a
  row and the picture jumps to that box. On a very large order, **Group same builds**
  collapses it to one row per distinct box build.

### 2 · 3D Loading Plan

The boxes on the vehicle, in loading order. Shell, labels, ghost, centre of gravity,
fillable area, lashing and tarpaulin can each be turned on. **Build** plays the load
in sequence; **Explode** separates the tiers. **Edit load** lets a box be dragged to
a new position by hand, with the unplaced tray along the bottom.

### 3 · 2D Plans

Top view, side elevation, rear view and tier plans, dimensioned, on paper — the
sheets that go to the loading bay.

### 4 · Actual Plan

Box-wise, loading-wise or the full report, and the same two export buttons.

---

## 4 · What comes out

| Button | File |
|---|---|
| 🗎 Check list | PACKING CHECK LIST + ANNEXURE, the works format (PDF) |
| Check list Excel | the same two forms as a workbook |
| Excel | packing list — Summary, Gasket Items, Box Manifest, **Box Contents**, Loading Sequence, Vehicles, Securing & Cover |
| PDF | loading plan — overview, 3-D and 2-D plans, box build-up, **What is in each box**, item summary, securing |
| Save | project JSON, reloadable |

**Box Contents** is one row per line per box: box number, outer size, item code,
customer code, description, type, size, rating, material, pieces, kilos, how packed
and whether it is nested.

---

## 5 · Checks and warnings

The right-hand rail carries the load summary, the vehicle list and **Checks &
warnings**. Read them — they are where the app tells you what it could not be sure
of:

- a line not on a works chart, so its size band and bundle count are a guess
- a size outside the bundle bands
- an annexure gross weight that disagrees with the contents, with the gap expressed
  as kg per m² of box so you can judge whether it means a pallet base or a mis-key
- a box that would need to be deeper than 30 in, or heavier than the cap
- a load whose centre is off the middle of the deck

---

## 6 · Light and dark

The app is light by default. The **☾** button in the header switches to the dark
palette and remembers the choice on that machine.

---

## 7 · Keeping it

Everything lives in the one HTML file. To keep a job, press **Save** and store the
JSON next to the works paperwork. To move the app to another machine, copy the HTML
file. There is nothing else to install.
