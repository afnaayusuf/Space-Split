# Training record — what was shared, and what each file taught

Every rule and every constant in GasketPack 3D traces back to something GOODRICH
GASKET sent. This is the log: the file, what was read out of it, and what changed
in the software because of it.

Where a file is listed as **held**, a copy belongs in `data/training/`. Where it is
listed as **described**, only the written instruction was given.

---

## A · The written rules

### A1 · Export packing (described, with two photographs)

> *"Export packing type rule … image one explains the export packing plan layout …
> KAMMprofile and double jacketed gaskets is all on an attached cardboard base …
> ISK and RTJ have a dedicated box … SC is informal … gaskets are not mixed with
> each other due to damage possibility and fragile nature."*
>
> *"Image two is how SPW are bundled — 0.5″ to 1″: 25 number bundle · 1.5″ to 8″:
> 10 number bundle · 10″–24″: 5 number bundle … ask me if there are gaskets beyond
> these dimensions."*

**Became:** Type 5, the export bundle bands, the "tightest bore" nester, the
one-type-per-box rule, cards for KAM/DJ, dedicated boxes for RTJ and ISK.

**Open question put back to the works:** sizes outside the bands. The app does not
invent a count — it warns.

### A2 · Domestic packing (described)

> *"1. SPW 12″–24″ and above are placed on cardboards. 2. 10″ 6″ 3″ gaskets go in
> the rings of each other. 3. 8″ 5″ 2.5″ — do into each other rings. 4. 0.5″ to 2″ —
> go in box as filler on sides or in between the bored rings to achieve efficiency.
> 4″ is nested in the rings. KAM and DJ — individual gaskets on cardboard square.
> ISK boxes, RTJ boxes."*
>
> *"Domestic packing qty SPW and SC — 0.5″ to 4″: 24 pc bundles · 6″ to 8″: 10 pc
> bundles · 10: 5 piece bundle · 12–24: individually placed on cardboard sheet
> square. Soft cut — both domestic and export: 0.5″ to 4″: 24 · 6″ to 8″: 10 ·
> 10 and above: 5."*
>
> *"KNPC type, general type, domestic type, export type."*

**Became:** Type 6, the domestic bands, the 10″ nesting cap, the two domestic chains,
the small-size filler rule, and the four named packing types in the rule selector.

### A3 · Two standing instructions

> *"Study the whole product list — suggest the best box layout required."*

**Became:** the **Suggested box layout** adviser, which reads the whole list against
both rules and shows the box count, pieces, weight and CBM each way before you commit.

> *"Leave one inch space on top half in gap on the internal box area side."*

**Became:** the clear inch of headroom kept above every stack, on every rule, and the
Headroom column on the box manifest.

---

## B · The charts and stock lists

| File | Status | What it gave | Where it lives |
|---|---|---|---|
| Spiral wound weight chart | held in code | 299 size × class rows incl. ASME B16.47 Series A and B | `parts/03b_chart.js` |
| Kammprofile chart | held in code | 151 rows | `parts/03b_chart.js` |
| Soft cut chart, plain and steel insert | held in code | 281 rows each | `parts/03b_chart.js` |
| RTJ ring chart | held in code | 232 ring numbers — R-OCT, R-OVAL, RX, BX | `parts/03b_chart.js` |
| Insulation kit chart | held in code | 391 rows, weight per complete set | `parts/03b_chart.js` |
| Material density sheet | held in code | 82 materials, the densities the charts were figured with | `parts/03_data.js` |
| **RTJ BOX.xlsx** | **held** | 120 ring cartons — side, depth, ply — and the corrugated square stock (19 sizes) and roll stock | `parts/03d_cartons.js` |
| **DJ WGT DETAILS.xlsx** | **held, not used** | a one-row double-jacketed weight calculator, not a table. Still open — see *Open items* | `data/training/` |

Every chart weight was re-derived from geometry and the density sheet and matched
the works figure, so the app can recompute a weight for a different material instead
of guessing.

---

## C · The real jobs

Five signed packing check lists were worked through. Each is built into the app
(**Works jobs** in the sidebar, newest first) and each has a regression test that
rebuilds its paperwork and fails if the software ever stops reproducing it.

### C1 · PRN GGPL/SE/SO/251000267 — TOYO ENGINEERING INDIA · 18-12-2025

3 spiral wound lines, 12 pieces, **one box 34 × 34 × 8 in at 53 kg**.

**Taught:** the consolidated habit — everything in a PRN goes in one box, sized to
the largest ring (here the 20″). First entry in the stock box ladder.

### C2 · PRN 251000300 — L&T ENERGY HYDROCARBON · 12-01-2026 · domestic

30 lines, **974 pieces, ten boxes, 2178 kg**, 7.13 CBM, surface dispatch. SPW 26″–60″
ASME B16.47 Series B, soft cut and RTJ.

**Taught — this is the job the domestic rules were calibrated against:**

- clearance ≈ **2 inches a side**
- bow allowance ≈ **OD ÷ 80** (1.25 %), spiral wound only
- box tare ≈ **1.6 ×** the bare model for their build
- a **300 kg** working cap per box
- **size clustering** — a 60″ ring does not share with a 30″ one
- the depth ladder up to 30 in
- Box 1 mixes soft cut, RTJ and a 10″ spiral wound → the small-size sharing rule

Type 4 reproduces the annexure exactly: 10 boxes, 974 pieces, 2178 kg, 7.13 CBM.

### C3 · PRN GGPL/SE/SO/251000304 — SHARP TANKS AND STRUCTURALS · 04-10-2025 · domestic

9 spiral wound lines, **285 pieces, two boxes**: 26 × 26 × 11 in (47 pcs, 103.00 kg)
and 21 × 21 × 25 in (238 pcs, 72.00 kg).

**Taught:**

- the clearest proof of the **12″ split** — 14″ and 12″ in one box, everything 8″ and
  under in the other
- Box 1's depth **disproves one sheet per ring** outside KNPC
- Box 2 confirms the box-weight model: **9.5 kg per m² of box surface**, within 4 %
  of the model, which is 12 mm ply

**Two queries raised with the works, both still open:**

1. The annexure total says **288 nos** where the two boxes add to **285**, and the
   nine line quantities also add to 285. The weight total (175.00 kg) is right.
2. **Box 1's 103.00 kg.** Contents are 55.6 kg, so the empty box would be 47.4 kg —
   **29.5 kg per m²**, three times what Box 2 implies. Either Box 1 was built on a
   pallet or skid base, or the weight is mis-keyed. 29 kg rides on every freight
   quote built from this sheet.

### C4 · PRN 251000316 — BHARAT HEAVY ELECTRICALS · 29-01-2026

Two PO lines of **the same part** — 8 + 82 = 90 pieces of SPW 5″×300# — in
**one box 21 × 21 × 11 in at 58 kg**.

**Taught:**

- the box can be sized by the **quantity**, not the ring: four columns of a 216 mm
  ring on a 489 mm floor
- a description can quote **two thicknesses** — `4.5MM GASKET THK 3MM RING THK` — and
  the 4.5 is the gasket while the 3 is the outer ring. The parser had been taking the
  3. Fixed, and it matches how the works chart is built.
- the same item code on two PO lines stays as two lines

### C5 · PRN 251000328 — TEMA INDIA · 05-02-2026

5 RTJ ring lines (R24, R37, R16, R49) plus one SPW 2″×2500#, **14 pieces, one box
14 × 14 × 10 in at 15.00 kg**.

**Taught:**

- **the ring carton sizes the box** — R49's 283 mm carton plus 36 mm a side is their
  14 in box, and twelve cartons stacked make the 10 in depth
- `SI` and `F5` are **materials** — soft iron and the chrome-moly forging. They were
  being read as "customer material". Now SI, F5, F9, F11, F12, F22, F51 and F53 are
  all recognised, and an RTJ keeps whatever bar is named instead of falling back to
  the generic ring-joint default.
- the third of their boxes that **mixes types** → the small-size sharing rule became
  the default

---

## D · Parser faults the real sheets exposed

Found while reading their own descriptions, all fixed and under test:

| Description as written | Was read as | Now |
|---|---|---|
| `SPW 30"X300# 316-OR+316/FG+316-IR` | quantity 316 | quantity blank |
| `… ASME B16.47` | quantity 47 | quantity blank |
| `SERIES-B` | Series A assumed | Series B |
| `4.5MM GASKET THK 3MM RING THK` | 3 mm gasket | 4.5 mm gasket, 3 mm ring, both kept |
| `RTJ R24 SI OCT` | customer material | soft iron |
| `RTJ R16 F5 OCT` | customer material | F5 |
| `RTJ R16 SS316L OCT` | generic ring joint | SS 316L (the grade suffix is kept) |
| `SC (RF) 20"X150# NON ASBESTOS BS7531` | spiral-wound assembly | CNAF |
| `SC (FF) 8"X150# BUTYL` | spiral-wound assembly | butyl rubber |
| soft cut family label | "Corrugated metal (CMGC)" | "Soft cut sheet (SC)" |
| `2,3,4 (50/50/10)` in a Box No cell | one box | split across boxes 2, 3 and 4 |

---

## E · Open items

1. **Gaskets outside the bundle bands** — the works was asked and has not answered.
   The app warns rather than guessing.
2. **PRN 251000304 Box 1 — 103.00 kg**: pallet base, or mis-key? (see C3)
3. **PRN 251000304 annexure total — 288 vs 285** (see C3)
4. **DJ WGT DETAILS.xlsx** — the double-jacketed weight formula has not been wired
   in. It is a one-row calculator rather than a table, so it needs a short
   conversation before it is trusted.

---

## F · Where to put the files

```
data/training/
  prn/      the signed packing check lists and annexures (PDF)
  charts/   the weight charts and the density sheet
  stock/    RTJ BOX.xlsx, corrugated stock
  misc/     DJ WGT DETAILS.xlsx and anything not yet used
```

The PDFs are scans; the app does not read them at run time. They are kept so that
any figure in the software can be traced back to the sheet it came from.
