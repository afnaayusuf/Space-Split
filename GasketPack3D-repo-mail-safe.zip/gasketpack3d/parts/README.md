# parts/

The source, concatenated by `../build.sh` in the order listed in
[../docs/DEVELOPER.md](../docs/DEVELOPER.md). Nothing here is a module — the build
is a `cat`, so these files share one global scope and the order is load-bearing.

If this folder is empty, the built app in `../dist/` can be split back into it:

```sh
node ../tools/split_html.mjs ../dist/GasketPack3D.html ./
```
