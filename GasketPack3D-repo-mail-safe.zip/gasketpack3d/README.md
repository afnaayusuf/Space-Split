# GasketPack 3D

**Gasket packing and load planning for GOODRICH GASKET PRIVATE LIMITED (Flosil).**

One self-contained HTML file. Open it in a browser — no install, no network, no
login. It takes a PRN's gasket lines, packs them the way the works packs them,
draws every box and the loaded vehicle in 3-D, and prints the works' own paperwork.

![version](https://img.shields.io/badge/version-4.1.0-orange) ![tests](https://img.shields.io/badge/node%20assertions-632-green) ![harnesses](https://img.shields.io/badge/browser%20harnesses-20-green)

---

## What it does

- **Packs to the works' rules** — KNPC, general, domestic and export packing, each
  as written: bundle counts by size band, bundles nested into the tightest bore,
  12″-and-up rings singly on corrugated squares, ring joints in their own cartons,
  no two gasket types in one box.
- **Uses the works' own data** — the spiral wound, Kammprofile, soft cut, RTJ and
  insulation-kit weight charts, the 82-material density sheet, the box shop's
  corrugated stock and its 120 RTJ carton sizes.
- **Shows the box, not a number** — every bundle, card and carton drawn where it
  sits, with a stack list that names each pile and singles it out on a click.
- **Loads the vehicle** — the Indian road fleet and the container sizes, with tier
  support, centre of gravity, lashing and tarpaulin.
- **Prints what the shop signs** — PACKING CHECK LIST and ANNEXURE in the works
  format, a packing list workbook with box-wise contents, and a loading plan PDF.
- **Reproduces real jobs** — five signed packing check lists are built in, and each
  has a test that fails if the software stops rebuilding its annexure exactly.

## Quick start

```sh
./build.sh                       # parts/* -> dist/GasketPack3D.html
open dist/GasketPack3D.html      # or just double-click it
```

To use it, see **[docs/USER-GUIDE.md](docs/USER-GUIDE.md)**.

## Documentation

| | |
|---|---|
| **[docs/PACKING-RULES.md](docs/PACKING-RULES.md)** | the works' packing practice, written down — every band, chain, clearance and cap, with the job each was read from |
| **[docs/TRAINING-DATA.md](docs/TRAINING-DATA.md)** | every file and instruction the works shared, what it taught, and the questions still open |
| **[docs/USER-GUIDE.md](docs/USER-GUIDE.md)** | how to use the app |
| **[docs/DEVELOPER.md](docs/DEVELOPER.md)** | architecture, build order, the 3-D engine, the layup, the tests |
| **[docs/CHANGELOG.md](docs/CHANGELOG.md)** | what changed, version by version |

## Layout

```
build.sh                 concatenates parts/* into dist/GasketPack3D.html
parts/                   the source, in build order (see docs/DEVELOPER.md)
dist/GasketPack3D.html   the deliverable — this is the whole application
docs/                    the written record
data/training/           the works' sheets the software was built from
tests/                   node assertion suites
harness/                 Playwright browser harnesses, incl. the performance budget
tools/                   build helpers — test runner, HTML splitter
```

## Tests

```sh
./tools/run_tests.sh
```

632 node assertions across ten suites and 20 browser harnesses. The PRN suites
rebuild five real jobs; `perf_test` holds the frame budget; `theme_browser` checks
both palettes for unreadable text.

## Status

Current version **4.1.0**. Built for GOODRICH GASKET PRIVATE LIMITED. Open items —
gaskets outside the bundle bands, the double-jacketed weight formula, and two
queries on PRN 251000304 — are listed in
[docs/TRAINING-DATA.md](docs/TRAINING-DATA.md#e--open-items).
